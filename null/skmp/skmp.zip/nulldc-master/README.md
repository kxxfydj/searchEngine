# nulldc
nullDC, a sega dreamcast emulator for win86.

I moved on to work on my new pet project, reicast, and while nullDC is still a 
better choice for dreamcast emulation on windows/x86 reicast is where the fun is.

This is here for archival & reference.
