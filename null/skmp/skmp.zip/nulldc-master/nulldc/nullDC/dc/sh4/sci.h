#pragma once

#include "types.h"

//Init/Res/Term
void sci_Init();
void sci_Reset(bool Manual);
void sci_Term();