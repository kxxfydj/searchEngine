class MapleDevice
{
};
