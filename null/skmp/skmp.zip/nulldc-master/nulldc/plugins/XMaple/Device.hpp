// even lower than FTx classes...
#ifndef MAPLEDEVICE_H
#define MAPLEDEVICE_H

class MapleDevice
{
public
	MapleDevice();
};

#endif //MAPLEDEVICE_H
