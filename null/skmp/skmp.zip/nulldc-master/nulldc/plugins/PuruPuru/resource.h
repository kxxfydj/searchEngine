//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PuruPuru.rc
//
#define IDD_CONFIG_DC                   101
#define IDB_BITMAP1                     103
#define IDB_BITMAP_ON                   104
#define IDB_BITMAP_ON2                  105
#define IDB_BITMAP_OFF                  106
#define IDD_ABOUT                       107
#define IDD_CONFIG1                     108
#define IDD_CONFIG_NAOMI                109
#define IDB_BITMAP4                     110
#define IDC_PORTTAB                     111
#define IDB_BITMAP2                     112
#define IDC_CONFIG_OFF                  200
#define IDC_CONFIG_ON                   201
#define IDC_CONFIG_ON2                  202
#define IDC_JOYNAME_SDL                 1001
#define IDC_JOYNAME_XINPUT              1002
#define IDC_JOYNAME_KEY                 1003
#define IDC_SHOULDERL                   1010
#define IDC_SHOULDERR                   1011
#define IDC_A                           1012
#define IDC_B                           1013
#define IDC_X                           1014
#define IDC_Y                           1015
#define IDC_START                       1016
#define IDC_DEADZONE                    1019
#define IDC_HALFPRESS                   1020
#define IDC_ABOUT1                      1021
#define IDC_PAKKU                       1021
#define IDC_DPAD_UP                     1022
#define IDC_DPAD_DOWN                   1023
#define IDC_DPAD_LEFT                   1024
#define IDC_DPAD_RIGHT                  1025
#define IDC_ABOUT3                      1026
#define IDC_STATEI                      1027
#define IDC_CONTROLTYPE                 1028
#define IDC_BUTTON1                     1029
#define IDABOUT                         1030
#define IDC_KEY                         1031
#define IDC_DPAD_TEXT1                  1037
#define IDC_DPAD_TEXT2                  1038
#define IDC_DPAD_TEXT3                  1039
#define IDC_DPAD_TEXT4                  1040
#define IDC_DPAD_TEXT5                  1041
#define IDC_DPAD_TEXT6                  1042
#define IDC_DPAD_TEXT7                  1043
#define IDC_DPAD_TEXT15                 1044
#define IDC_DPAD_TEXT8                  1045
#define IDC_DPAD_TEXT16                 1046
#define IDC_DPAD_TEXT17                 1047
#define IDC_DPAD_TEXT9                  1048
#define IDC_DPAD_TEXT10                 1049
#define IDC_DPAD_RIGHT3                 1052
#define IDC_DPAD_TEXT11                 1053
#define IDC_DPAD_TEXT12                 1054
#define IDC_DPAD_TEXT13                 1055
#define IDC_DPAD_TEXT14                 1056
#define IDC_PAKKU_TEXT                  1065
#define IDC_NBUTTON1                    1100
#define IDC_NBUTTON2                    1101
#define IDC_NBUTTON3                    1102
#define IDC_NBUTTON4                    1103
#define IDC_NBUTTON5                    1104
#define IDC_NBUTTON6                    1105
#define IDC_SERVICE1                    1106
#define IDC_TEST1                       1107
#define IDC_SERVICE2                    1108
#define IDC_TEST2                       1109
#define IDC_COIN                        1110
#define IDTEXT_SHOULDERL                2010
#define IDTEXT_SHOULDERR                2011
#define IDTEXT_A                        2012
#define IDTEXT_B                        2013
#define IDTEXT_X                        2014
#define IDTEXT_Y                        2015
#define IDTEXT_START                    2016
#define IDTEXT_HALFPRESS                2020
#define IDTEXT_DPAD_UP                  2022
#define IDTEXT_DPAD_DOWN                2023
#define IDTEXT_DPAD_LEFT                2024
#define IDTEXT_DPAD_RIGHT               2025
#define IDTEXT_NBUTTON1                 2100
#define IDTEXT_NBUTTON2                 2101
#define IDTEXT_NBUTTON3                 2102
#define IDTEXT_NBUTTON4                 2103
#define IDTEXT_NBUTTON5                 2104
#define IDTEXT_NBUTTON6                 2105
#define IDTEXT_SERVICE1                 2106
#define IDTEXT_TEST1                    2107
#define IDTEXT_SERVICE2                 2108
#define IDTEXT_TEST2                    2109
#define IDTEXT_COIN                     2110
#define IDC_MX_L                        3001
#define IDC_MX_R                        3002
#define IDC_MY_U                        3003
#define IDC_MY_D                        3004
#define IDTEXT_MX_L                     4001
#define IDTEXT_MX_R                     4002
#define IDTEXT_MY_U                     4003
#define IDTEXT_MY_D                     4004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1066
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
