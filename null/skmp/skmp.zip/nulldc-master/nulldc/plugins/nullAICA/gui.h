#include <windowsx.h>
#include "nullAICA.h"
#include "resource.h"
extern u32 config_scmi,config_stami,config_stami2;
void ShowConfig(HWND parent);
void ShowDebugger(HWND parent);
void Cofnig_UpdateMenuSelections();
