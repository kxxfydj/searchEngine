#pragma once
#include "drkPvr.h"
#include "ta.h"
#include "TexCache.h"

extern u32 VertexCount;
extern u32 FrameCount;

#include "d3dRend.h"
#include "d3dRend11.h"
#include "nullRend.h"