#pragma once
#include "common.h"

Disc* chd_parse(wchar* file);