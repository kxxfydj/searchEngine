#pragma once
#include "common.h"

Disc* gdi_parse(wchar* file);