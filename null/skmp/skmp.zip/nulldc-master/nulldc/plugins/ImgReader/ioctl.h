#pragma once
#include "common.h"

Disc* ioctl_parse(wchar* file);