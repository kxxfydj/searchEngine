#pragma once
#include "common.h"

Disc* cdi_parse(wchar* file);