# Python presence and chat bridge

## Install

`pip install -r demos/requirements.txt`

## Run

`python server.py`
