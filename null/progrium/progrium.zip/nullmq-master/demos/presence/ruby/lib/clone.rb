module Clone
  autoload :Server, 'clone/server'
  autoload :Client, 'clone/client'
end
