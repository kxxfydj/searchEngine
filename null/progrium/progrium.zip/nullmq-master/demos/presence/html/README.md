# Presence html frontend

## Run

`python -m SimpleHTTPServer 8080`

## Use

* make sure to start python bridge and ruby chat and presence servers first
* go to `http://localhost:8080/` in your browser
