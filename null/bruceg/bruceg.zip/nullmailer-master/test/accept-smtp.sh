echo 250 OK
echo 250 OK
echo 250 OK
echo 250 OK
echo 351 OK
echo 220 OK
sleep 1
