#ifndef NULLMAILER__CANONICALIZE__H__
#define NULLMAILER__CANONICALIZE__H__

#include "mystring/mystring.h"
void canonicalize(mystring& domain);

#endif // NULLMAILER__CANONICALIZE__H__
