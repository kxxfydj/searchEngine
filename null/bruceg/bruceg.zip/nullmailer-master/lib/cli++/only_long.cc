#include "cli++.h"

const bool cli_only_long = false;
