#ifndef NULLMAILER__ADDRESS__H__
#define NULLMAILER__ADDRESS__H__

#include "mystring/mystring.h"

bool parse_addresses(mystring& line, mystring& list);

#endif // NULLMAILER__ADDRESS__H__
