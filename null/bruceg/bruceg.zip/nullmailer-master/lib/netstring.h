#ifndef NULLMAILER__NETSTRING__H__
#define NULLMAILER__NETSTRING__H__

#include "mystring/mystring.h"
mystring str2net(const mystring&);
mystring strnl2net(const mystring&);

#endif // NULLMAILER__NETSTRING__H__
