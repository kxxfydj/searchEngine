#ifndef NULLMAILER__HOSTNAME__H__
#define NULLMAILER__HOSTNAME__H__

extern mystring me;
extern mystring defaulthost;
extern mystring defaultdomain;

void read_hostnames();

#endif
