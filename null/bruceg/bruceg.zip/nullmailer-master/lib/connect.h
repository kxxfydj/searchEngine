#ifndef NULLMAILER_CONNECT__H__
#define NULLMAILER_CONNECT__H__

extern int tcpconnect(const char* hostname, int port, const char* source);

#endif // NULLMAILER_CONNECT__H__
