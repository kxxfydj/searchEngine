#ifndef NULLMAILER__SETENV__H__
#define NULLMAILER__SETENV__H__

extern "C" int setenv(const char*, const char*, int);

#endif
