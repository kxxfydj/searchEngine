## 1.1.0

  - [Make it possible to supply an example object to mimic, with no class.](https://github.com/avdi/naught/commit/df2b62c027812760ce200177ce056929b5aea339)
  - [Define implicit conversion for to_hash](https://github.com/avdi/naught/commit/e20dc472d3bc71ba927d6ddb0fb0032e1646df77)
  - [Define implicit conversion for to_int](https://github.com/avdi/naught/commit/d32d4ea32a9a847bffd6cf18f480bdfaaf7a3641)

## 1.0.0

  - [Replace `::BasicObject` with `Naught::BasicObject`](https://github.com/avdi/naught/commit/8defad0bf9eb65e33054bf0a6e9c625c87c3e6df)
  - [Delegate explicit conversions to nil instead of defining them explicitly](https://github.com/avdi/naught/commit/85c195de80ed56993b88f47e09112c903a92a167)
  - Add support for (and run tests on) Ruby 1.8, 1.9, 2.0, 2.1, JRuby, and Rubinius

## 0.0.3

Features:

  - New "pebble" mode (Guilherme Carvalho)

