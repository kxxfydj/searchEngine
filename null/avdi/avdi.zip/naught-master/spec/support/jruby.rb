def jruby?
  RUBY_PLATFORM == 'java'
end
