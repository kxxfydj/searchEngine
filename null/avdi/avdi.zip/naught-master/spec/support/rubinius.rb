def rubinius?
  defined?(RUBY_ENGINE) && RUBY_ENGINE == 'rbx'
end
