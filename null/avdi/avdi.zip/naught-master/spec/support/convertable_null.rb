ConvertableNull = Naught.build do |b|
  b.null_equivalents << ''
  b.traceable
end
