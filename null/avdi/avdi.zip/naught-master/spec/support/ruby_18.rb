def ruby_18?
  RUBY_VERSION.to_f == 1.8
end
