﻿class EmptyDerivedClass<Q> : GenericBaseClass<int, Q>
{
}