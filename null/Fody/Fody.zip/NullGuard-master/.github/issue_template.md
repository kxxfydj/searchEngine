Complete as many of the following as possible

 * [ ] Uploaded a minimal solution that reproduces the problem with the fewest moving pieces. Preferably a public GitHub repository.
 * [ ] Submitted a PR (https://help.github.com/articles/about-pull-requests/) with a failing unit test.
 * [ ] Submitted a PR (https://help.github.com/articles/about-pull-requests/) with a fix.
 
Want to see Fody survive and evolve? Consider supporting the collective: https://opencollective.com/fody/donate