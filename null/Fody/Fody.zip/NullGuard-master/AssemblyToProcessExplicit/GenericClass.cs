public class GenericClass<T> {
    [JetBrains.Annotations.NotNull]
    public T NonNullProperty { get; set; }
}