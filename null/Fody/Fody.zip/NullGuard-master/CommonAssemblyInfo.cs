﻿using System.Reflection;

[assembly: AssemblyTitle("NullGuard")]
[assembly: AssemblyProduct("NullGuard")]