public class GenericClass<T>
{
    public T NonNullProperty { get; set; }
}