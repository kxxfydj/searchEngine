using Windows.UI.Xaml.Markup;

public class XamlMetadataProvider : IXamlMetadataProvider
{
    
}