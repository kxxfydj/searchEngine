internal class NonPublicWithNested
{
    public class PublicNestedClass
    {
        public string MethodReturnsNull()
        {
            return null;
        }
    }
}