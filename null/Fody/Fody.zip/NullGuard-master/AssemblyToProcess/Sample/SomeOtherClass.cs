public class SomeOtherClass
{
    public static string SomeMethod()
    {
        return null;
    }
}