namespace Windows.UI.Xaml.Markup
{
    public interface IXamlMetadataProvider{}
}