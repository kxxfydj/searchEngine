
public class UnsafeClass
{
	unsafe public int* MethodWithAmp(int* instance)
	{
		return default;
	}
	unsafe public int* NullProperty { get; set; }
}