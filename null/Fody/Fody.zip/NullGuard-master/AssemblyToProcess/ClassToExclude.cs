public class ClassToExclude
{
    // ReSharper disable once UnusedParameter.Local
    public ClassToExclude(string test)
    {
    }

    public string Test(string text)
    {
        return text;
    }

    public string Property { get; set; }
}