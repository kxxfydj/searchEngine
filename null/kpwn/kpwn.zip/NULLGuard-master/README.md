# NULLGuard

This prevents binaries lacking __PAGEZERO from running.

Among other things, it fixes tpwn and renders a _ton_ of bugs unexploitable.

note: some older binaries (10.4?) could also be affected, but I haven't yet encountered a non-malicious binary lacking PAGEZERO.
