Template.timestampPopup.helpers({
    timeago() {
        return Session.get('now');
    }
});
