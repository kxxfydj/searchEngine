Template.layout.helpers({
    loggedIn() {
        return !!Meteor.userId();
    }
});
