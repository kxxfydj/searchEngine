Template.starsModal.onCreated(function () {
    this.subscribe('starredMessages');
});
