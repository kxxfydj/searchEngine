Template.memeModal.onCreated(function () {
    this.subscribe('memes');
});
