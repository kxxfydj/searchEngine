:mod:`zipline.utils` subpackage
===============================

.. automodule:: zipline.utils.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`factory` Module
---------------------

.. automodule:: zipline.utils.factory
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`protocol_units` Module
----------------------------

.. automodule:: zipline.utils.protocol_utils
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`simfactory` Module
--------------------------

.. automodule:: zipline.utils.simfactory
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`test_utils` Module
------------------------

.. automodule:: zipline.utils.test_utils
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tradingcalendar` Module
------------------------------

.. automodule:: zipline.utils.tradingcalendar
    :members:
    :undoc-members:
    :show-inheritance:

