**********
Quickstart
**********

Dual-Moving Average Example
===========================

The following code implements a simple dual moving average algorithm
and tests it on data extracted from yahoo finance.

.. include:: ../zipline/examples/dual_moving_average.py
   :literal:

You can find other examples in `the zipline/examples directory <https://github.com/quantopian/zipline/tree/master/zipline/examples>`_.
