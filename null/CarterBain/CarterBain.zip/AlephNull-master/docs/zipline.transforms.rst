:mod:`zipline.transforms` subpackage
=====================================

.. automodule:: zipline.transforms.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mavg` Module
-------------------------

.. automodule:: zipline.transforms.mavg
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`returns` Module
-------------------------

.. automodule:: zipline.transforms.returns
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`stddev` Module
-------------------------

.. automodule:: zipline.transforms.stddev
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`utils` Module
-------------------------

.. automodule:: zipline.transforms.utils
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`vwap` Module
-------------------------

.. automodule:: zipline.transforms.vwap
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`talib` Module
-------------------------

.. automodule:: zipline.transforms.ta
    :members:
    :undoc-members:
    :show-inheritance:
