:mod:`zipline.gens` subpackage
==============================

.. automodule:: zipline.gens.__init__
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`composites` Module
-------------------------

.. automodule:: zipline.gens.composites
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tradesimulation` Module
------------------------------

.. automodule:: zipline.gens.tradesimulation
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`utils` Module
---------------------

.. automodule:: zipline.gens.utils
    :members:
    :undoc-members:
    :show-inheritance:

